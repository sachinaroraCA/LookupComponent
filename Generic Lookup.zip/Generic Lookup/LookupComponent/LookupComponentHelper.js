({
    doInitHelper: function (component, event, helper) {
        if (component.get('v.selItemText') && component.get('v.selItemId')) {
            let selItem = {};
            selItem.text = component.get('v.selItemText');
            selItem.Id = component.get('v.selItemId');
            component.set("v.selItem", selItem);
        }
    },
    itemSelected: function (component, event, helper) {
        let target = event.target;
        let SelIndex = helper.getIndexFrmParent(target, helper, "data-selectedIndex");
        if (SelIndex) {
            let serverResult = component.get("v.server_result");
            let selItem = serverResult[SelIndex];
            if (selItem.Id) {
                component.set("v.selItem", selItem);
                component.set("v.selItemId", selItem.Id); 
                component.set("v.selItemText", selItem.text);
                component.set("v.last_ServerResult", serverResult);
                let cmp = component.find('addborder');
                component.set("v.searchText", undefined);
                //  $A.util.addClass(cmp,'slds-has-inline-listbox');
            }
            component.set("v.server_result", null);
        }
    },
    firstServerCall: function (component, event, helper) {
        //Escape button pressed
        if (event.keyCode == 27) {
            helper.clearSelection(component, event, helper);
        } else {
            if (component.get('v.searchText') == '') {
                //Save server call, if last text not changed
                let objectName = component.get("v.objectName");
                let field_API_text = component.get("v.field_API_text");
                let field_API_val = component.get("v.field_API_val");
                let field_API_search = component.get("v.field_API_search");
                let limit = component.get("v.limit");
                let parentFiledName = component.get("v.parentFiledName");
                let parentFiledId = component.get("v.parentFiledId");
                let searchTextStartsWithFilter = component.get("v.searchTextStartsWithFilter");
                let action = component.get('c.searchDB');
                action.setStorable();
                action.setParams({
                    objectName: objectName,
                    fld_API_Text: field_API_text,
                    fld_API_Val: field_API_val,
                    lim: limit,
                    fld_API_Search: field_API_search,
                    searchText: null,
                    parentFiledName: parentFiledName,
                    parentFiledId: parentFiledId,
                    searchTextStartsWithFilter: searchTextStartsWithFilter
                });
                action.setCallback(this, function (a) {
                    this.handleResponse(a, component, helper);
                });
                $A.enqueueAction(action);
            }
        }
    },
    serverCall: function (component, event, helper) {
        let target = event.target;
        // let searchText = target.value;
        let searchText = component.get("v.searchText");
        let last_SearchText = component.get("v.last_SearchText");
        //Escape button pressed
        if (event.keyCode == 27 || !searchText.trim()) {
            helper.clearSelection(component, event, helper);
        } else if (searchText.trim() != last_SearchText) {
            //Save server call, if last text not changed
            let objectName = component.get("v.objectName");
            let field_API_text = component.get("v.field_API_text");
            let field_API_val = component.get("v.field_API_val");
            let field_API_search = component.get("v.field_API_search");
            let limit = component.get("v.limit");
            let parentFiledName = component.get("v.parentFiledName");
            let parentFiledId = component.get("v.parentFiledId");
            let searchTextStartsWithFilter = component.get("v.searchTextStartsWithFilter");
            let action = component.get('c.searchDB');
            action.setStorable();
            
            action.setParams({
                objectName: objectName,
                fld_API_Text: field_API_text,
                fld_API_Val: field_API_val,
                lim: limit,
                fld_API_Search: field_API_search,
                searchText: searchText,
                parentFiledName: parentFiledName,
                parentFiledId: parentFiledId,
                searchTextStartsWithFilter: searchTextStartsWithFilter
            });
            action.setCallback(this, function (a) {
                this.handleResponse(a, component, helper);
            });
            component.set("v.last_SearchText", searchText.trim());
            $A.enqueueAction(action);
        } else if (searchText && last_SearchText && searchText.trim() == last_SearchText.trim()) {
            component.set("v.server_result", component.get("v.last_ServerResult"));
        }
    },
    handleResponse: function (res, component, helper) {
        if (res.getState() === 'SUCCESS') {
            if (res.getReturnValue() != null) {
                let retObj = JSON.parse(res.getReturnValue());
                if (retObj.length <= 0) {
                    let noResult = JSON.parse('[{"text":"No Results Found"}]');
                    component.set("v.server_result", noResult);
                    component.set("v.last_ServerResult", noResult);
                } else {
                    component.set("v.server_result", retObj);
                    component.set("v.last_ServerResult", retObj);
                }
            }
        } else if (res.getState() === 'ERROR') {
            let errors = res.getError();
            if (errors) {
                if (errors[0] && errors[0].message) {
                    alert(errors[0].message);
                }
            }
        }
    },
    getIndexFrmParent: function (target, helper, attributeToFind) {
        //User can click on any child element, so traverse till intended parent found
        if (target !== null) {
            let SelIndex = target.getAttribute(attributeToFind);
            while (!SelIndex) {
                target = target.parentNode;
                SelIndex = helper.getIndexFrmParent(target, helper, attributeToFind);
            }
            return SelIndex;
        }
        
    },
    clearSelection: function (component, event, helper) {
        component.set("v.selItem", null);
        component.set("v.selItemId", null);
        component.set("v.server_result", null);
        component.set("v.searchText", '');
        let cmp = component.find('addborder');
        //  $A.util.removeClass(cmp,'slds-has-inline-listbox');
    },
    
});